<?php
include 'inc/header.php';
Session::CheckSession();
$sId =  Session::get('roleid');
if ($sId === '1') { ?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addUser'])) {

  $userAdd = $users->addNewPnt($_POST);
}

if (isset($userAdd)) {
  echo $userAdd;
}


 ?>


 <div class="card ">
   <div class="card-header">
          <h3 class='text-center'>Add New User</h3>
        </div>
        <div class="cad-body">



            <div style="width:600px; margin:0px auto">

            <form class="" action="" method="post">
                <div class="form-group pt-3">
                  <label for="name">Name</label>
                  <input type="text" name="name"  class="form-control">
                </div>
                <div class="form-group">
                  <label for="username">Address</label>
                  <input type="text" name="address"  class="form-control">
                </div>
                <div class="form-group">
                  <label for="email">Age</label>
                  <input type="text" name="age"  class="form-control">
                </div>
                <div class="form-group">
                  <label for="mobile">Phone</label>
                  <input type="text" name="phone"  class="form-control">
                </div>
                <div class="form-group">
                  <label for="mobile">Gender</label>
                  <input type="text" name="gender"  class="form-control">
                
                
                
              
                <div class="form-group">
                  <button type="submit" name="addUser" class="btn btn-success">Submit</button>
                </div>


            </form>
          </div>


        </div>
      </div>

<?php
}else{

  header('Location:index.php');



}
 ?>

  <?php
  include 'inc/footer.php';

  ?>
